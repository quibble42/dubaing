<?php 
//made with help from those at stackexchange (helper acct: Alive to Die)
error_reporting(E_ALL);
ini_set('display_errors',1);

if(empty($_POST['email']) || empty($_POST['toures'])) 

{
   echo "Please go back and choose whether you are a resident or tourist. Sorry for the inconvenience.";
}else{
    
    $dbServername = 'dubaingae.ipagemysql.com';
    $dbUsername = 'johndubaingae';
    $dbPassword = 'mostadventureswillfail';
    $dbName = 'dubaingdatabase';

    $conn = mysqli_connect($dbServername, $dbUsername, $dbPassword,$dbName); 
    //check conneced or not
    if(!$conn){ // $ missed
     die('connection problem 999999'.mysqli_connect_error());
    }else{
        $email = $_POST['email'];// remove ()
        $radio = $_POST['toures'];
        $stmt = mysqli_prepare($conn, "INSERT INTO email_list (email, toures) VALUES (?, ?)");
        mysqli_stmt_bind_param($stmt, "si", $email, $radio);

        if(mysqli_stmt_execute($stmt)){//check query executes or not
            header("Location: ../index.html?signup=success");
            exit();
        }else{
            exit();
        }
    }
}